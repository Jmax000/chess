# chess
chess

- [ ] create github repo
- [ ] clone to dev
- [ ] creat the intellij proj
- [ ] inti chess starter code
- [ ] get code to compile
- [ ] get the test to run
