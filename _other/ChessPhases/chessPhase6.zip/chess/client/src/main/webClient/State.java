package webClient;

public enum State
{
    SIGNED_OUT,
    SIGNED_IN,
    IN_GAME,
    OBSERVING
}
