package requestResultObjects;

public class JoinGameResult
{
    private String message;

    public JoinGameResult() {}


    // … Getters and Setters for message, authToken, and username properties
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
