package webClient;

public enum State
{
    SIGNEDOUT,
    SIGNEDIN
}
